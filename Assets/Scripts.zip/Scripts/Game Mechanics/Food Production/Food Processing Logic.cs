using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class FoodPL : MonoBehaviour
{
    public static FoodPL instance;
    public List<TheFood> materials;
    private List<TheFood> OriginalMaterials;
    public List<FoodLevelSystem> lSystem;
    public Animator anim;

    public TextMeshProUGUI AnimalFoodText;

    public Sprite foodImage;
    public TextMeshProUGUI timer;

    [Header("Material Holder")]
    public Transform mholder;
    public GameObject materialPrefab;
    public List<GameObject> Materials;
    public List<Sprite> FHIcons;

    [Header("Schedule Holder")]
    public Transform qholder;
    public GameObject qPrefab;
    public List<GameObject> queue;
    public Sprite buyButton;
    public Button mBtn;

    [Header("Upgrade System")]
    public List<Sprite> MachineImages;
    public Image priceImage;
    public TextMeshProUGUI priceText;

    public Image Icon;
    public Image TheWell;
    public Image NextWell;

    [Header("Upgrade Parameters")]
    public TextMeshProUGUI cPTD;
    public TextMeshProUGUI nPTD;
    public TextMeshProUGUI cFTI;
    public TextMeshProUGUI nFTI;
    public TextMeshProUGUI cPrX;
    public TextMeshProUGUI nPrX;

    public List<int> sPrices = new List<int>() { 300, 500, 750 };

    private void Awake()
    {
        instance = this;

        anim = GetComponent<Animator>();
        AnimalFoodText.text = StaticDatas.PlayerData.PlayerInfos.Food.sumAmount.ToString();

        mBtn.onClick.RemoveAllListeners();
        mBtn.onClick.AddListener(() => PopulateMatHolder());
        OriginalMaterials = new List<TheFood>(materials);
        SetImages();
        changeFood();
        PopulateSchedule();
        PopulateFoodList();
    }

    private void Update()
    {
        if (StaticDatas.PlayerData.PlayerInfos.Food.MachState == LandState.Planted)
        {
            if (StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].PrState == PlantState.Growing)
            { CheckGrowth(); UpdateTimer(); }
            else if (StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].PrState == PlantState.ReadyToHarvest)
                rtCollect();
        }
        else
        {
            mBtn.onClick.RemoveAllListeners(); mBtn.onClick.AddListener(() => PopulateMatHolder()); 
        }
        LoadUI();
    }

    private void LoadUI()
    {
        if (StaticDatas.PlayerData.PlayerInfos.Food.MachState == LandState.Empty)
        {
            timer.gameObject.SetActive(false);
            queue[0].transform.Find("BG").GetComponent<Image>().color = Color.darkBlue;
        }
        else
        {
            timer.gameObject.SetActive(true);
            if (StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].PrState == PlantState.Growing)
            {
                queue[0].transform.Find("Skip Button").gameObject.SetActive(true);
                if(queue.Count > 0)
                    queue[0].transform.Find("BG").GetComponent<Image>().color = Color.darkBlue;
            }
            else if (StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].PrState == PlantState.ReadyToHarvest)
            {
                queue[0].transform.Find("Skip Button").gameObject.SetActive(false);
                if (queue.Count > 0)
                    queue[0].transform.Find("BG").GetComponent<Image>().color = Color.green;
            }
        }
    }

    #region Animations
        public void OpenDetails()
        {
            if (WaterSL.instance.anim.GetBool("Open Water Details"))
                WaterSL.instance.anim.SetBool("Open Water Details", false);
            if (Storage.instance.anim.GetBool("Open Storage"))
                Storage.instance.anim.SetBool("Open Storage", false);
            if (TasksLogic.instance.anim.GetBool("Open Task Board"))
                TasksLogic.instance.anim.SetBool("Open Task Board", false);
            if (anim.GetBool("Open Upgrade"))
                    CloseUpgrade();
                else if (anim.GetBool("Open MH"))
                    OpenMH(false);
                if(StaticDatas.PlayerData.PlayerInfos.FoodLevel >= MachineImages.Count)
                    transform.Find("Food Producer/Holder Colored/Details/Upgrade Button").gameObject.SetActive(false);

                int id = Animator.StringToHash("Open Details");
                Debug.Log($"Open Details is {anim.GetBool(id)}");
                Debug.Log($"Setting to {!anim.GetBool(id)}");

                anim.SetBool(id, !anim.GetBool(id));
            }

        public void OpenFH()
        {
            transform.Find("Food Producer/Foods in Storage").GetComponent<Animator>().SetBool("Open Food Holder",
                !transform.Find("Food Producer/Foods in Storage").GetComponent<Animator>().GetBool("Open Food Holder"));
        }

        public void OpenMH(bool tf)
        {
            if (!anim.GetBool("Open Upgrade"))
            {
                Debug.Log($"Setting to {tf}");
                anim.SetBool("Open MH", tf);
                mBtn.onClick.RemoveAllListeners();
                mBtn.onClick.AddListener(() => PopulateMatHolder());
            }
        }

        public void OpenUpgrade()
        {
            if (anim.GetBool("Open MH"))
                anim.SetBool("Open MH", false);
            if (!anim.GetBool("Open Upgrade"))
            {
                Debug.Log($"Setting to {!anim.GetBool("Open Upgrade")}");
                anim.SetBool("Open Upgrade", true);
                mBtn.onClick.RemoveAllListeners();
                priceImage.sprite = Sprites.instance.GetSpriteFromSource(lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel].currency);
                priceText.text = lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel].price.ToString();
            }
            else
                UpgradeWellLevel();
        }

        public void CloseUpgrade()
        {
            if (anim.GetBool("Open Upgrade"))
            {
                Debug.Log($"Setting to {!anim.GetBool("Open Upgrade")}");
                anim.SetBool("Open Upgrade", false);
                mBtn.onClick.RemoveAllListeners();
                mBtn.onClick.AddListener(() => PopulateMatHolder());
            }
        }
        #endregion

    #region Production Section
        private void ChooseProduct(TheFood tf)
        {
            if (Storage.instance.hasEnought(tf.material, tf.reqAmount, true) && StaticDatas.PlayerData.PlayerInfos.Food.InQueue.Count < StaticDatas.PlayerData.PlayerInfos.Food.qLimit)
            {
                Storage.instance.UpdateThingCount(tf.material, -tf.reqAmount);

                TheFood newItem = tf.Clone();
                newItem.PrState = PlantState.Growing;

                List<TheFood> inqueue = StaticDatas.PlayerData.PlayerInfos.Food.InQueue;

                if (inqueue.Count == 0)
                {
                    newItem.fillTime = DateTime.UtcNow.ToString("o");
                }
                else
                {
                    bool passed = StaticDatas.TryGetStartTime(inqueue[inqueue.Count - 1].fillTime, "Food", out DateTime lastFinish);
                    newItem.fillTime = lastFinish.AddMinutes(inqueue[inqueue.Count - 1].pTimer).ToString("o");
                }

                inqueue.Add(newItem);
                StaticDatas.PlayerData.PlayerInfos.Food.InQueue = inqueue;
                StaticDatas.PlayerData.PlayerInfos.Food.MachState = LandState.Planted;
                StaticDatas.SaveDatas();

                queue[StaticDatas.PlayerData.PlayerInfos.Food.InQueue.Count - 1].transform.Find("Item").GetComponent<Image>().sprite =
                    Sprites.instance.GetSpriteFromSource(tf.Food);
                queue[StaticDatas.PlayerData.PlayerInfos.Food.InQueue.Count - 1].transform.Find("Item").GetComponent<Image>().enabled = true;
                if (StaticDatas.PlayerData.PlayerInfos.Food.InQueue.Count >= StaticDatas.PlayerData.PlayerInfos.Food.qLimit){
                    PopulateMatHolder();
                }
                PopulateSchedule();
                PlantsHolder.instance.UpdateCountOfPlants();
            }
        }

        private void CheckGrowth()
        {
            double elapsedMinutes;
            if (!StaticDatas.ElapsedMinutes(StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].fillTime, "Food Timer", out elapsedMinutes)) return;
            CalculateSkipCost(out int cost);
            if (StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].PrState == PlantState.Growing && elapsedMinutes >
            StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].pTimer)
            {
                StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].PrState = PlantState.ReadyToHarvest;
                Debug.Log("Plant state set to ready");
                StaticDatas.SaveDatas();
            }
        }

        private void UpdateTimer()
        {
            DateTime startTime;
            if (!StaticDatas.TryGetStartTime(StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].fillTime, "Food Timer", out startTime)) return;
            float time = 0;
            for (int i = 0; i < StaticDatas.PlayerData.PlayerInfos.Food.InQueue.Count; i++)
            {
                if (StaticDatas.PlayerData.PlayerInfos.Food.InQueue[i].PrState != PlantState.ReadyToHarvest)
                    { time = StaticDatas.PlayerData.PlayerInfos.Food.InQueue[i].pTimer; break; }
            }
            double totalSecondsRequired = time * 60;
            double elapsedSeconds = (DateTime.UtcNow - startTime).TotalSeconds;

            string timeString = StaticDatas.convertToTimer(totalSecondsRequired, elapsedSeconds);
            timer.text = timeString;
        }

        private void PopulateMatHolder()
        {
            if(!anim.GetBool("Open Upgrade"))
            {
                foreach (Transform item in mholder) Destroy(item.gameObject);
                if (StaticDatas.PlayerData.PlayerInfos.Food.qLimit > StaticDatas.PlayerData.PlayerInfos.Food.InQueue.Count)
                {
                    for (int i = 0; i < StaticDatas.PlayerData.PlayerInfos.Food.materials.Count; i++)
                    {
                        var proto = materials.Find(e => e.material == StaticDatas.PlayerData.PlayerInfos.Food.materials[i].material);
                        TheFood tf = proto.Clone();
                        Debug.Log($"in popmatholder: Food {tf.Food} \n material {tf.material}");
                        if (StaticDatas.PlayerData.unlocked_items.u_plants.Contains(tf.material))
                        {
                            GameObject dublicate = Instantiate(materialPrefab, mholder);
                            dublicate.GetComponent<Image>().sprite = Sprites.instance.GetSpriteFromSource(tf.material);
                            dublicate.GetComponent<RectTransform>().sizeDelta = new Vector2(65, 65);
                            dublicate.transform.Find("Price").gameObject.SetActive(false);

                            Button button = dublicate.GetComponent<Button>();
                            button.onClick.RemoveAllListeners();
                            button.onClick.AddListener(() => ChooseProduct(tf));
                        }
                    }
                    OpenMH(true);
                }
                else
                {
                    OpenMH(false);
                    mBtn.onClick.RemoveAllListeners();
                }
            }
        }

        private void PopulateSchedule()
        {
            foreach (Transform item in qholder) Destroy(item.gameObject);
            queue.Clear();
            for (int i = queue.Count; i < StaticDatas.PlayerData.PlayerInfos.Food.qLimit; i++)
            {
                Debug.Log($"qLimit is {StaticDatas.PlayerData.PlayerInfos.Food.qLimit}");
                GameObject dublicate = Instantiate(qPrefab, qholder);
                if (i < StaticDatas.PlayerData.PlayerInfos.Food.InQueue.Count)
                {
                    dublicate.transform.name = "Animal Food";
                    dublicate.transform.Find("Item").GetComponent<Image>().enabled = true;
                    dublicate.transform.Find("Item").GetComponent<Image>().sprite = Sprites.instance.GetSpriteFromSource(StaticDatas.PlayerData.PlayerInfos.Food.InQueue[i].Food);
                    dublicate.transform.Find("Price").gameObject.SetActive(false);

                    #region Skip Button
                        Transform skip = dublicate.transform.Find("Price");
                        skip.name = "Skip Button";
                        skip.gameObject.SetActive(true);
                        skip.Find("Icon").GetComponent<Image>().sprite = Sprites.instance.GetSpriteFromSource(Currency.Crystal);
                        RectTransform srts = skip.GetComponent<RectTransform>();
                        skip.GetComponent<Button>().onClick.RemoveAllListeners();
                        skip.GetComponent<Button>().onClick.AddListener(() => SkipFood());

                        if(i > 0 || StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].PrState != PlantState.Growing) skip.gameObject.SetActive(false);
                    #endregion
                }
                else
                {
                    dublicate.transform.name = "Empty Slot";
                    dublicate.transform.Find("Item").GetComponent<Image>().enabled = false;
                    dublicate.transform.Find("Price").gameObject.SetActive(false);
                }
                dublicate.transform.Find("BG").GetComponent<Image>().color = Color.darkBlue;
                dublicate.GetComponent<RectTransform>().localScale = new Vector3(1 - (float)(i * 0.08), 1 - (float)(i * 0.08), 1 - (float)(i * 0.08));
                Debug.Log($"slot added to queue");
                queue.Add(dublicate);
                CalculateSkipCost(out int cost);
            }
                int add = 0;
                if (StaticDatas.PlayerData.PlayerInfos.Food.qLimit < 4)
                {
                    Debug.Log($"adding addbuyslot");
                    AddBuySlot(); add = 1;
                }
                RectTransform rts = qholder.GetComponent<RectTransform>();
                HorizontalLayoutGroup hlg = qholder.GetComponent<HorizontalLayoutGroup>();
                rts.sizeDelta = new Vector2(((StaticDatas.PlayerData.PlayerInfos.Food.qLimit + add) * 80) + (hlg.padding.left * 2) + (StaticDatas.PlayerData.PlayerInfos.Food.qLimit * hlg.spacing), 100);
            }

        private void CalculateSkipCost(out int cost)
        {
            cost = 0;
            if(StaticDatas.PlayerData.PlayerInfos.Food.InQueue.Count > 0)
            {
                Debug.Log($"StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].pTimer = {StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].pTimer}");
                cost = StaticDatas.FindSkipCost(StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].fillTime, "Food", StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].pTimer);
                Debug.Log($"cost = {cost}");
                queue[0].transform.Find("Skip Button/Price Text").GetComponent<TextMeshProUGUI>().text = cost.ToString();
            }
        }

        private void SkipFood()
        {
            CalculateSkipCost(out int cost);
            if (MoneySystem.instance.hasEnough(Currency.Crystal, cost))
            {
                MoneySystem.instance.UpdateCyrstal(-cost, out bool enought);
                StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].PrState = PlantState.ReadyToHarvest;
                if (StaticDatas.PlayerData.PlayerInfos.Food.InQueue.Count > 1) StaticDatas.PlayerData.PlayerInfos.Food.InQueue[1].fillTime = DateTime.UtcNow.ToString("o");
                queue[0].transform.Find("Skip Button").gameObject.SetActive(false);
                LoadUI();
            }
        }

        private void AddBuySlot()
        {
            if(StaticDatas.PlayerData.PlayerInfos.Food.qLimit < 5)
            {
                int i = StaticDatas.PlayerData.PlayerInfos.Food.qLimit + 1;
                GameObject buy = Instantiate(qPrefab, qholder);
                buy.transform.name = "Buy Slot";
                buy.transform.Find("Item").GetComponent<Image>().sprite = buyButton;
                buy.transform.Find("Price").gameObject.SetActive(true);
                buy.transform.Find("Price/Price Text").GetComponent<TextMeshProUGUI>().text = sPrices[StaticDatas.PlayerData.PlayerInfos.Food.qLimit - 1].ToString();
                buy.GetComponent<RectTransform>().localScale = new Vector3(1 - (float)(i * 0.08), 1 - (float)(i * 0.08), 1 - (float)(i * 0.08));

                Button btn = buy.GetComponent<Button>();
                btn.onClick.RemoveAllListeners();
                btn.onClick.AddListener(() => BuySlot());
            }
        }

        private void BuySlot()
        {
            if(MoneySystem.instance.hasEnough(Currency.Coin, sPrices[StaticDatas.PlayerData.PlayerInfos.Food.qLimit - 1]))
            {
                StaticDatas.PlayerData.PlayerInfos.Food.qLimit++;
                MoneySystem.instance.UpdateCoin(-sPrices[StaticDatas.PlayerData.PlayerInfos.Food.qLimit - 2], out bool s);
                MoneySystem.instance.UpdateXp(StaticDatas.PlayerData.PlayerInfos.Food.qLimit * 20);
                Transform child = qholder.Find("Buy Slot");
                if (child != null) Destroy(child.gameObject);
                PopulateSchedule();
                LuckyBox.instance.TryToFindBox(0.3f * StaticDatas.PlayerData.PlayerInfos.Food.qLimit);
                mBtn.onClick.RemoveAllListeners();
                mBtn.onClick.AddListener(() => PopulateMatHolder());
                StaticDatas.SaveDatas();
            }
        }

        private void rtCollect()
        {
            mBtn.onClick.RemoveAllListeners();
            mBtn.onClick.AddListener(() => Collect());
        }

        private void Collect()
        {
            if (!anim.GetBool("Open Upgrade") && StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].PrState == PlantState.ReadyToHarvest &&
                Storage.instance.hasEnStorage(StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].collectAmount, true))
            {
                Storage.instance.UpdateThingCount(StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].Food, StaticDatas.PlayerData.PlayerInfos.Food.InQueue[0].collectAmount);
                MoneySystem.instance.UpdateXp(StaticDatas.PlayerData.PlayerInfos.Food.xp);
                queue[StaticDatas.PlayerData.PlayerInfos.Food.InQueue.Count - 1].transform.Find("Item").GetComponent<Image>().enabled = false;
                StaticDatas.PlayerData.PlayerInfos.Food.InQueue.RemoveAt(0);

                if (StaticDatas.PlayerData.PlayerInfos.Food.InQueue.Count <= 0)
                    StaticDatas.PlayerData.PlayerInfos.Food.MachState = LandState.Empty;
                if (AnimalsLogic.instance != null)
                    AnimalsLogic.instance.PopulateFoodChooser();
                StaticDatas.SaveDatas();
                mBtn.onClick.RemoveAllListeners();
                mBtn.onClick.AddListener(() => PopulateMatHolder());
                LuckyBox.instance.TryToFindBox(0.3f);
                PopulateSchedule();
            }
            //else if (StaticDatas.PlayerData.PlayerInfos.Food.InQueue.Count < StaticDatas.PlayerData.PlayerInfos.Food.qLimit) PopulateMatHolder();
        }
    #endregion

    #region Upgrage System
        public void UpgradeWellLevel()
        {
            if (MoneySystem.instance.hasEnough(lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel].currency, lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel].price))
            {
                if (StaticDatas.PlayerData.PlayerInfos.FoodLevel < MachineImages.Count)
                {
                    StaticDatas.PlayerData.PlayerInfos.FoodLevel++;
                    if (StaticDatas.PlayerData.PlayerInfos.FoodLevel < MachineImages.Count)
                    {
                        //CheckLevel();
                        changeFood();
                        SetImages();
                        StaticDatas.SaveDatas();
                        priceImage.sprite = Sprites.instance.GetSpriteFromSource(lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel].currency);
                        priceText.text = lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel].price.ToString();
                    }
                    else FinishLevel();

                    if (lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel - 1].currency == Currency.Coin)
                        MoneySystem.instance.UpdateCoin(-lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel - 1].price, out bool s);
                    else if (lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel - 1].currency == Currency.Crystal)
                        MoneySystem.instance.UpdateCyrstal(-lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel - 1].price, out bool s);
                    MoneySystem.instance.UpdateXp(lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel - 1].xp);

                    LuckyBox.instance.TryToFindBox(0.5f * StaticDatas.PlayerData.PlayerInfos.FoodLevel);
                }
                else return;

            }
        }

        private void SetImages()
        {
            Icon.sprite = MachineImages[StaticDatas.PlayerData.PlayerInfos.FoodLevel - 1];
            TheWell.sprite = MachineImages[StaticDatas.PlayerData.PlayerInfos.FoodLevel - 1];

            if(StaticDatas.PlayerData.PlayerInfos.FoodLevel < MachineImages.Count)
            {
                cPTD.text = lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel - 1].progTimerDec.ToString() + "%";
                cFTI.text = lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel - 1].foodTimerInc.ToString() + "%";
                cPrX.text = lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel - 1].productionX.ToString();

                nPTD.text = lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel].progTimerDec.ToString() + "%";
                nFTI.text = lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel].foodTimerInc.ToString() + "%";
                nPrX.text = lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel].productionX.ToString();

                NextWell.sprite = MachineImages[StaticDatas.PlayerData.PlayerInfos.FoodLevel];
            }
        }

        private void FinishLevel()
        {
            Icon.sprite = MachineImages[StaticDatas.PlayerData.PlayerInfos.FoodLevel -1];
            TheWell.sprite = MachineImages[StaticDatas.PlayerData.PlayerInfos.FoodLevel - 1];
            changeFood();
            CloseUpgrade();
            transform.Find("Food Producer/Holder Colored/Details/Upgrade Button").gameObject.SetActive(false);
        }
    #endregion

    public void reSizeFoodsHolder()
    {
        Transform holder = transform.Find("Food Producer/Foods in Storage/Holder");
        foreach (Transform food in holder)
        {
            food.GetComponent<RectTransform>().sizeDelta = new Vector2(55, 55);
            food.transform.Find("Count").GetComponent<RectTransform>().sizeDelta = new Vector2(65, 22);
            food.transform.Find("Count").GetComponent<RectTransform>().localPosition = new Vector2(0, -45);
            food.GetComponent<Image>().color = new Color32(255, 255, 255, 255);

            if(food.transform.Find("Minute"))
                Destroy(food.transform.Find("Minute").gameObject);
            Destroy(food.GetComponent<Button>());
        }
    }

    private void PopulateFoodList()
    {
        for (int i = StaticDatas.PlayerData.PlayerInfos.Food.Amounts.Count; i < StaticDatas.PlayerData.PlayerInfos.Food.materials.Count; i++)
        {
            StaticDatas.PlayerData.PlayerInfos.Food.Amounts.Add(new afAmount()
            {
                food = StaticDatas.PlayerData.PlayerInfos.Food.materials[i].Food,
                amount = 0
            });
            StaticDatas.SaveDatas();
        }
    }

    private void changeFood()
    {
        for (int i = 0; i < materials.Count; i++)
        {
            TheFood f = new TheFood()
            {
                pTimer = OriginalMaterials[i].pTimer - (((materials[i].pTimer) / 100) * lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel - 1].progTimerDec),
                foodTimer = OriginalMaterials[i].foodTimer + (((materials[i].foodTimer) / 100) * lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel - 1].foodTimerInc),
                collectAmount = OriginalMaterials[i].collectAmount * lSystem[StaticDatas.PlayerData.PlayerInfos.FoodLevel - 1].productionX
            };
            materials[i].pTimer = f.pTimer;
            materials[i].foodTimer = f.foodTimer;
            materials[i].collectAmount = f.collectAmount;
        }
        Storage.instance.CalSumOfFood();
        StaticDatas.PlayerData.PlayerInfos.Food.materials = materials;
        StaticDatas.SaveDatas();
    }
}
